<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" /> -->
    <title>Maxime Lefebvre - Team Lead DevOps</title>
    <link rel="stylesheet" href="./css/bulma.min.css" />
    <!-- <link rel="stylesheet" href="./css/bulma-rtl.min.css" /> -->
    <link rel="stylesheet" href="./css/icons/css/fontawesome.min.css" />
    <link rel="stylesheet" href="./css/icons/css/brands.min.css" />
    <link rel="stylesheet" href="./css/icons/css/regular.min.css" />
    <link rel="stylesheet" href="./css/icons/css/solid.min.css" />
    <link rel="stylesheet" href="./css/style.css" />
</head>
<body>
    
    <div class="menu">
        <a href="">Intérêts</a>
        <a href="">Compétences</a>
        <a href="">Formations</a>
        <a href="">Expériences</a>
        <a href="">Contact</a>
    </div>

    <div class="section marronFonce">
        <div class="titre">
            <i class="fa-solid fa-terminal"></i>
            Présentation
        </div>
        <div class="columns is-mobile contentPres">
            <div class="column">
                <img src="./img/profil.jpg" alt="Photo de profil" />
            </div>
            <div class="column infoPres">
                <p>
                    <i class="fa-solid fa-user"></i>
                    MAXIME LEFEBVRE
                </p>
                <p>
                    <i class="fa-solid fa-briefcase"></i>
                    Team Lead DevOps
                </p>
                <p>
                    <i class="fa-solid fa-cake-candles"></i>
                    Né le 15 mai 1998
                </p>
                <p>
                    <i class="fa-solid fa-at"></i>
                    maximelefebvre1505@gmail.com
                </p>
                <p>
                    <i class="fa-solid fa-car"></i>
                    Permis B + voiture
                </p>
            </div>
        </div>
    </div>

    <div class="section marronClair">
        <div class="titre">
            <i class="fa-solid fa-terminal"></i>
            Mes Intérêts
        </div>
        <div class="contentInterets">
            <p>
                <i class="fa-solid fa-hand-fist"></i>
                Kick-Boxing / Boxe Thaï en Club depuis 2014 (élève et encadrant)
            </p>
            <p>
                <i class="fa-solid fa-computer"></i>
                Hight-Tech
            </p>
            <p>
                <i class="fa-solid fa-file-code"></i>
                Développement web
            </p>
            <p>
                <i class="fa-solid fa-gamepad"></i>
                Jeux vidéos
            </p>
            <p>
                <i class="fa-solid fa-film"></i>
                Grand fan de séries
            </p>
        </div>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

</body>
</html>